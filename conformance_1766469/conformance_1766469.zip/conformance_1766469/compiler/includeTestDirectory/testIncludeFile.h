/******************************************************************
//
//  OpenCL Conformance Tests
//
//  Version:    1.0
//
//  Copyright:    (c) 2008-2013 by Apple Inc. All Rights Reserved.
//
******************************************************************/

#define HEADER_FOUND 12

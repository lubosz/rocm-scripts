/******************************************************************
//
//  OpenCL Conformance Tests
//
//  Copyright:    (c) 2008-2013 by Apple Inc. All Rights Reserved.
//
******************************************************************/

#define HEADER_FOUND 42
